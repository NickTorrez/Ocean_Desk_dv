﻿namespace Ocean_Desk_dv.UI.Catalogs
{
    partial class FrmCaja
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            DataGridViewCellStyle dataGridViewCellStyle1 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle2 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle9 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle10 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle11 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle3 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle4 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle5 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle6 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle7 = new DataGridViewCellStyle();
            DataGridViewCellStyle dataGridViewCellStyle8 = new DataGridViewCellStyle();
            pnlEstadoCaja = new Panel();
            lblDetalleCaja = new Label();
            lblEstadoCaja = new Label();
            lblEstadoTitulo = new Label();
            pnlResumen = new Panel();
            tlpResumen = new TableLayoutPanel();
            pnlResumenApertura = new Panel();
            lblValorApertura = new Label();
            lblTituloApertura = new Label();
            pnlResumenIngresos = new Panel();
            lblValorIngresos = new Label();
            lblTituloIngresos = new Label();
            pnlResumenEgresos = new Panel();
            lblValorEgresos = new Label();
            lblTituloEgresos = new Label();
            pnlResumenEsperado = new Panel();
            lblValorEsperado = new Label();
            lblTituloEsperado = new Label();
            pnlMovimientos = new Panel();
            dgvMovimientosCaja = new DataGridView();
            colFecha = new DataGridViewTextBoxColumn();
            colTipo = new DataGridViewTextBoxColumn();
            colConcepto = new DataGridViewTextBoxColumn();
            colMetodo = new DataGridViewTextBoxColumn();
            colMonto = new DataGridViewTextBoxColumn();
            colUsuario = new DataGridViewTextBoxColumn();
            pnlAcciones = new Panel();
            tableLayoutPanel1 = new TableLayoutPanel();
            btnCerrarCaja = new Button();
            tlpButtons = new TableLayoutPanel();
            btnAbrirCaja = new Button();
            btnRegistrarEgreso = new Button();
            btnRegistrarIngreso = new Button();
            pnlUltimoCierre = new Panel();
            tlpUltimoCierre = new TableLayoutPanel();
            pnlUltimoCierreFecha = new Panel();
            lblUltimoCierreFecha = new Label();
            pnlUltimoCierreEsperado = new Panel();
            lblUltimoCierreEsperado = new Label();
            pnlUltimoCierreContado = new Panel();
            lblUltimoCierreContado = new Label();
            pnlUltimoCierreDiferencia = new Panel();
            lblUltimoCierreDiferencia = new Label();
            pnlUltimoCierreUsuario = new Panel();
            lblUltimoCierreUsuario = new Label();
            lblTituloUltimoCierre = new Label();
            pnlEstadoCaja.SuspendLayout();
            pnlResumen.SuspendLayout();
            tlpResumen.SuspendLayout();
            pnlResumenApertura.SuspendLayout();
            pnlResumenIngresos.SuspendLayout();
            pnlResumenEgresos.SuspendLayout();
            pnlResumenEsperado.SuspendLayout();
            pnlMovimientos.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)dgvMovimientosCaja).BeginInit();
            pnlAcciones.SuspendLayout();
            tableLayoutPanel1.SuspendLayout();
            tlpButtons.SuspendLayout();
            pnlUltimoCierre.SuspendLayout();
            tlpUltimoCierre.SuspendLayout();
            pnlUltimoCierreFecha.SuspendLayout();
            pnlUltimoCierreEsperado.SuspendLayout();
            pnlUltimoCierreContado.SuspendLayout();
            pnlUltimoCierreDiferencia.SuspendLayout();
            pnlUltimoCierreUsuario.SuspendLayout();
            SuspendLayout();
            // 
            // pnlEstadoCaja
            // 
            pnlEstadoCaja.BackColor = Color.White;
            pnlEstadoCaja.Controls.Add(lblDetalleCaja);
            pnlEstadoCaja.Controls.Add(lblEstadoCaja);
            pnlEstadoCaja.Controls.Add(lblEstadoTitulo);
            pnlEstadoCaja.Dock = DockStyle.Top;
            pnlEstadoCaja.Location = new Point(0, 0);
            pnlEstadoCaja.Margin = new Padding(0);
            pnlEstadoCaja.Name = "pnlEstadoCaja";
            pnlEstadoCaja.Padding = new Padding(15, 10, 15, 10);
            pnlEstadoCaja.Size = new Size(940, 70);
            pnlEstadoCaja.TabIndex = 0;
            // 
            // lblDetalleCaja
            // 
            lblDetalleCaja.Dock = DockStyle.Fill;
            lblDetalleCaja.Font = new Font("Century Gothic", 7.8F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblDetalleCaja.ForeColor = Color.FromArgb(111, 119, 128);
            lblDetalleCaja.Location = new Point(225, 10);
            lblDetalleCaja.Name = "lblDetalleCaja";
            lblDetalleCaja.Padding = new Padding(5, 0, 0, 0);
            lblDetalleCaja.Size = new Size(700, 50);
            lblDetalleCaja.TabIndex = 2;
            lblDetalleCaja.Text = "Apertura: 26/08/2026 08:00 a. m.";
            lblDetalleCaja.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // lblEstadoCaja
            // 
            lblEstadoCaja.BackColor = Color.White;
            lblEstadoCaja.Dock = DockStyle.Left;
            lblEstadoCaja.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblEstadoCaja.ForeColor = Color.Black;
            lblEstadoCaja.Location = new Point(135, 10);
            lblEstadoCaja.Name = "lblEstadoCaja";
            lblEstadoCaja.Size = new Size(90, 50);
            lblEstadoCaja.TabIndex = 1;
            lblEstadoCaja.Text = "ABIERTA";
            lblEstadoCaja.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lblEstadoTitulo
            // 
            lblEstadoTitulo.Dock = DockStyle.Left;
            lblEstadoTitulo.Font = new Font("Century Gothic", 10.2F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblEstadoTitulo.ForeColor = Color.FromArgb(8, 31, 63);
            lblEstadoTitulo.Location = new Point(15, 10);
            lblEstadoTitulo.Name = "lblEstadoTitulo";
            lblEstadoTitulo.Size = new Size(120, 50);
            lblEstadoTitulo.TabIndex = 0;
            lblEstadoTitulo.Text = "Caja Actual:";
            lblEstadoTitulo.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // pnlResumen
            // 
            pnlResumen.BackColor = Color.Transparent;
            pnlResumen.Controls.Add(tlpResumen);
            pnlResumen.Dock = DockStyle.Top;
            pnlResumen.Location = new Point(0, 70);
            pnlResumen.Name = "pnlResumen";
            pnlResumen.Padding = new Padding(0, 10, 0, 10);
            pnlResumen.Size = new Size(940, 105);
            pnlResumen.TabIndex = 1;
            // 
            // tlpResumen
            // 
            tlpResumen.ColumnCount = 4;
            tlpResumen.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tlpResumen.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tlpResumen.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tlpResumen.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tlpResumen.Controls.Add(pnlResumenApertura, 0, 0);
            tlpResumen.Controls.Add(pnlResumenIngresos, 1, 0);
            tlpResumen.Controls.Add(pnlResumenEgresos, 2, 0);
            tlpResumen.Controls.Add(pnlResumenEsperado, 3, 0);
            tlpResumen.Dock = DockStyle.Fill;
            tlpResumen.Location = new Point(0, 10);
            tlpResumen.Name = "tlpResumen";
            tlpResumen.RowCount = 1;
            tlpResumen.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tlpResumen.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tlpResumen.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tlpResumen.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tlpResumen.Size = new Size(940, 85);
            tlpResumen.TabIndex = 0;
            // 
            // pnlResumenApertura
            // 
            pnlResumenApertura.BackColor = Color.White;
            pnlResumenApertura.Controls.Add(lblValorApertura);
            pnlResumenApertura.Controls.Add(lblTituloApertura);
            pnlResumenApertura.Dock = DockStyle.Fill;
            pnlResumenApertura.Location = new Point(5, 5);
            pnlResumenApertura.Margin = new Padding(5);
            pnlResumenApertura.Name = "pnlResumenApertura";
            pnlResumenApertura.Padding = new Padding(12);
            pnlResumenApertura.Size = new Size(225, 75);
            pnlResumenApertura.TabIndex = 0;
            // 
            // lblValorApertura
            // 
            lblValorApertura.Dock = DockStyle.Fill;
            lblValorApertura.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblValorApertura.ForeColor = Color.FromArgb(8, 31, 63);
            lblValorApertura.Location = new Point(12, 32);
            lblValorApertura.Name = "lblValorApertura";
            lblValorApertura.Size = new Size(201, 31);
            lblValorApertura.TabIndex = 1;
            lblValorApertura.Text = "C$ 0.00";
            // 
            // lblTituloApertura
            // 
            lblTituloApertura.Dock = DockStyle.Top;
            lblTituloApertura.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblTituloApertura.ForeColor = Color.FromArgb(111, 119, 128);
            lblTituloApertura.Location = new Point(12, 12);
            lblTituloApertura.Name = "lblTituloApertura";
            lblTituloApertura.Size = new Size(201, 20);
            lblTituloApertura.TabIndex = 0;
            lblTituloApertura.Text = "Apertura";
            // 
            // pnlResumenIngresos
            // 
            pnlResumenIngresos.BackColor = Color.White;
            pnlResumenIngresos.Controls.Add(lblValorIngresos);
            pnlResumenIngresos.Controls.Add(lblTituloIngresos);
            pnlResumenIngresos.Dock = DockStyle.Fill;
            pnlResumenIngresos.Location = new Point(240, 5);
            pnlResumenIngresos.Margin = new Padding(5);
            pnlResumenIngresos.Name = "pnlResumenIngresos";
            pnlResumenIngresos.Padding = new Padding(12);
            pnlResumenIngresos.Size = new Size(225, 75);
            pnlResumenIngresos.TabIndex = 1;
            // 
            // lblValorIngresos
            // 
            lblValorIngresos.Dock = DockStyle.Fill;
            lblValorIngresos.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblValorIngresos.ForeColor = Color.FromArgb(42, 122, 82);
            lblValorIngresos.Location = new Point(12, 32);
            lblValorIngresos.Name = "lblValorIngresos";
            lblValorIngresos.Size = new Size(201, 31);
            lblValorIngresos.TabIndex = 2;
            lblValorIngresos.Text = "C$ 0.00";
            // 
            // lblTituloIngresos
            // 
            lblTituloIngresos.Dock = DockStyle.Top;
            lblTituloIngresos.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblTituloIngresos.ForeColor = Color.FromArgb(111, 119, 128);
            lblTituloIngresos.Location = new Point(12, 12);
            lblTituloIngresos.Name = "lblTituloIngresos";
            lblTituloIngresos.Size = new Size(201, 20);
            lblTituloIngresos.TabIndex = 2;
            lblTituloIngresos.Text = "Ingresos";
            // 
            // pnlResumenEgresos
            // 
            pnlResumenEgresos.BackColor = Color.White;
            pnlResumenEgresos.Controls.Add(lblValorEgresos);
            pnlResumenEgresos.Controls.Add(lblTituloEgresos);
            pnlResumenEgresos.Dock = DockStyle.Fill;
            pnlResumenEgresos.Location = new Point(475, 5);
            pnlResumenEgresos.Margin = new Padding(5);
            pnlResumenEgresos.Name = "pnlResumenEgresos";
            pnlResumenEgresos.Padding = new Padding(12);
            pnlResumenEgresos.Size = new Size(225, 75);
            pnlResumenEgresos.TabIndex = 2;
            // 
            // lblValorEgresos
            // 
            lblValorEgresos.Dock = DockStyle.Fill;
            lblValorEgresos.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblValorEgresos.ForeColor = Color.FromArgb(163, 61, 61);
            lblValorEgresos.Location = new Point(12, 32);
            lblValorEgresos.Name = "lblValorEgresos";
            lblValorEgresos.Size = new Size(201, 31);
            lblValorEgresos.TabIndex = 3;
            lblValorEgresos.Text = "C$ 0.00";
            // 
            // lblTituloEgresos
            // 
            lblTituloEgresos.Dock = DockStyle.Top;
            lblTituloEgresos.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblTituloEgresos.ForeColor = Color.FromArgb(111, 119, 128);
            lblTituloEgresos.Location = new Point(12, 12);
            lblTituloEgresos.Name = "lblTituloEgresos";
            lblTituloEgresos.Size = new Size(201, 20);
            lblTituloEgresos.TabIndex = 3;
            lblTituloEgresos.Text = "Egresos";
            // 
            // pnlResumenEsperado
            // 
            pnlResumenEsperado.BackColor = Color.White;
            pnlResumenEsperado.Controls.Add(lblValorEsperado);
            pnlResumenEsperado.Controls.Add(lblTituloEsperado);
            pnlResumenEsperado.Dock = DockStyle.Fill;
            pnlResumenEsperado.Location = new Point(710, 5);
            pnlResumenEsperado.Margin = new Padding(5);
            pnlResumenEsperado.Name = "pnlResumenEsperado";
            pnlResumenEsperado.Padding = new Padding(12);
            pnlResumenEsperado.Size = new Size(225, 75);
            pnlResumenEsperado.TabIndex = 3;
            // 
            // lblValorEsperado
            // 
            lblValorEsperado.Dock = DockStyle.Fill;
            lblValorEsperado.Font = new Font("Century Gothic", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblValorEsperado.ForeColor = Color.FromArgb(8, 126, 164);
            lblValorEsperado.Location = new Point(12, 32);
            lblValorEsperado.Name = "lblValorEsperado";
            lblValorEsperado.Size = new Size(201, 31);
            lblValorEsperado.TabIndex = 4;
            lblValorEsperado.Text = "C$ 0.00";
            // 
            // lblTituloEsperado
            // 
            lblTituloEsperado.Dock = DockStyle.Top;
            lblTituloEsperado.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblTituloEsperado.ForeColor = Color.FromArgb(111, 119, 128);
            lblTituloEsperado.Location = new Point(12, 12);
            lblTituloEsperado.Name = "lblTituloEsperado";
            lblTituloEsperado.Size = new Size(201, 20);
            lblTituloEsperado.TabIndex = 4;
            lblTituloEsperado.Text = "Esperado";
            // 
            // pnlMovimientos
            // 
            pnlMovimientos.BackColor = Color.Transparent;
            pnlMovimientos.Controls.Add(dgvMovimientosCaja);
            pnlMovimientos.Dock = DockStyle.Fill;
            pnlMovimientos.Location = new Point(0, 260);
            pnlMovimientos.Name = "pnlMovimientos";
            pnlMovimientos.Padding = new Padding(3, 10, 3, 10);
            pnlMovimientos.Size = new Size(940, 570);
            pnlMovimientos.TabIndex = 2;
            // 
            // dgvMovimientosCaja
            // 
            dgvMovimientosCaja.AllowUserToAddRows = false;
            dgvMovimientosCaja.AllowUserToDeleteRows = false;
            dgvMovimientosCaja.AllowUserToResizeRows = false;
            dataGridViewCellStyle1.BackColor = Color.FromArgb(248, 250, 252);
            dataGridViewCellStyle1.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dataGridViewCellStyle1.ForeColor = Color.FromArgb(8, 31, 63);
            dataGridViewCellStyle1.SelectionBackColor = Color.LightCyan;
            dataGridViewCellStyle1.SelectionForeColor = Color.FromArgb(8, 31, 63);
            dgvMovimientosCaja.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            dgvMovimientosCaja.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dgvMovimientosCaja.BackgroundColor = Color.White;
            dgvMovimientosCaja.BorderStyle = BorderStyle.None;
            dgvMovimientosCaja.CellBorderStyle = DataGridViewCellBorderStyle.SingleHorizontal;
            dataGridViewCellStyle2.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = Color.FromArgb(8, 31, 63);
            dataGridViewCellStyle2.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dataGridViewCellStyle2.ForeColor = Color.White;
            dataGridViewCellStyle2.Padding = new Padding(6, 0, 0, 0);
            dataGridViewCellStyle2.SelectionBackColor = Color.FromArgb(8, 31, 63);
            dataGridViewCellStyle2.SelectionForeColor = Color.White;
            dataGridViewCellStyle2.WrapMode = DataGridViewTriState.True;
            dgvMovimientosCaja.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            dgvMovimientosCaja.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvMovimientosCaja.Columns.AddRange(new DataGridViewColumn[] { colFecha, colTipo, colConcepto, colMetodo, colMonto, colUsuario });
            dataGridViewCellStyle9.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = Color.White;
            dataGridViewCellStyle9.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dataGridViewCellStyle9.ForeColor = Color.FromArgb(8, 31, 63);
            dataGridViewCellStyle9.SelectionBackColor = Color.FromArgb(224, 234, 240);
            dataGridViewCellStyle9.SelectionForeColor = Color.FromArgb(8, 31, 63);
            dataGridViewCellStyle9.WrapMode = DataGridViewTriState.False;
            dgvMovimientosCaja.DefaultCellStyle = dataGridViewCellStyle9;
            dgvMovimientosCaja.Dock = DockStyle.Fill;
            dgvMovimientosCaja.EnableHeadersVisualStyles = false;
            dgvMovimientosCaja.GridColor = Color.FromArgb(230, 234, 238);
            dgvMovimientosCaja.Location = new Point(3, 10);
            dgvMovimientosCaja.MultiSelect = false;
            dgvMovimientosCaja.Name = "dgvMovimientosCaja";
            dgvMovimientosCaja.ReadOnly = true;
            dataGridViewCellStyle10.Alignment = DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = SystemColors.Control;
            dataGridViewCellStyle10.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dataGridViewCellStyle10.ForeColor = SystemColors.WindowText;
            dataGridViewCellStyle10.SelectionBackColor = SystemColors.Highlight;
            dataGridViewCellStyle10.SelectionForeColor = SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = DataGridViewTriState.True;
            dgvMovimientosCaja.RowHeadersDefaultCellStyle = dataGridViewCellStyle10;
            dgvMovimientosCaja.RowHeadersVisible = false;
            dgvMovimientosCaja.RowHeadersWidth = 51;
            dataGridViewCellStyle11.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            dgvMovimientosCaja.RowsDefaultCellStyle = dataGridViewCellStyle11;
            dgvMovimientosCaja.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dgvMovimientosCaja.Size = new Size(934, 550);
            dgvMovimientosCaja.TabIndex = 0;
            dgvMovimientosCaja.CellFormatting += dgvMovimientosCaja_CellFormatting;
            // 
            // colFecha
            // 
            colFecha.DataPropertyName = "Fecha";
            dataGridViewCellStyle3.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle3.Format = "g";
            dataGridViewCellStyle3.NullValue = null;
            colFecha.DefaultCellStyle = dataGridViewCellStyle3;
            colFecha.FillWeight = 15F;
            colFecha.HeaderText = "Fecha";
            colFecha.MinimumWidth = 6;
            colFecha.Name = "colFecha";
            colFecha.ReadOnly = true;
            // 
            // colTipo
            // 
            colTipo.DataPropertyName = "Tipo";
            dataGridViewCellStyle4.Alignment = DataGridViewContentAlignment.MiddleCenter;
            colTipo.DefaultCellStyle = dataGridViewCellStyle4;
            colTipo.FillWeight = 15F;
            colTipo.HeaderText = "Tipo";
            colTipo.MinimumWidth = 6;
            colTipo.Name = "colTipo";
            colTipo.ReadOnly = true;
            // 
            // colConcepto
            // 
            colConcepto.DataPropertyName = "Concepto";
            dataGridViewCellStyle5.Alignment = DataGridViewContentAlignment.MiddleLeft;
            colConcepto.DefaultCellStyle = dataGridViewCellStyle5;
            colConcepto.FillWeight = 30F;
            colConcepto.HeaderText = "Concepto";
            colConcepto.MinimumWidth = 6;
            colConcepto.Name = "colConcepto";
            colConcepto.ReadOnly = true;
            // 
            // colMetodo
            // 
            colMetodo.DataPropertyName = "MetodoPago";
            dataGridViewCellStyle6.Alignment = DataGridViewContentAlignment.MiddleCenter;
            colMetodo.DefaultCellStyle = dataGridViewCellStyle6;
            colMetodo.FillWeight = 15F;
            colMetodo.HeaderText = "Método";
            colMetodo.MinimumWidth = 6;
            colMetodo.Name = "colMetodo";
            colMetodo.ReadOnly = true;
            // 
            // colMonto
            // 
            colMonto.DataPropertyName = "Monto";
            dataGridViewCellStyle7.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle7.Format = "N2";
            dataGridViewCellStyle7.NullValue = null;
            colMonto.DefaultCellStyle = dataGridViewCellStyle7;
            colMonto.FillWeight = 15F;
            colMonto.HeaderText = "Monto";
            colMonto.MinimumWidth = 6;
            colMonto.Name = "colMonto";
            colMonto.ReadOnly = true;
            // 
            // colUsuario
            // 
            colUsuario.DataPropertyName = "Usuario";
            dataGridViewCellStyle8.Alignment = DataGridViewContentAlignment.MiddleCenter;
            colUsuario.DefaultCellStyle = dataGridViewCellStyle8;
            colUsuario.FillWeight = 10F;
            colUsuario.HeaderText = "Usuario";
            colUsuario.MinimumWidth = 6;
            colUsuario.Name = "colUsuario";
            colUsuario.ReadOnly = true;
            // 
            // pnlAcciones
            // 
            pnlAcciones.BackColor = Color.White;
            pnlAcciones.Controls.Add(tableLayoutPanel1);
            pnlAcciones.Controls.Add(tlpButtons);
            pnlAcciones.Dock = DockStyle.Bottom;
            pnlAcciones.Location = new Point(0, 765);
            pnlAcciones.Name = "pnlAcciones";
            pnlAcciones.Padding = new Padding(15, 6, 15, 8);
            pnlAcciones.Size = new Size(940, 65);
            pnlAcciones.TabIndex = 1;
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 1;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 20F));
            tableLayoutPanel1.Controls.Add(btnCerrarCaja, 0, 0);
            tableLayoutPanel1.Dock = DockStyle.Right;
            tableLayoutPanel1.Location = new Point(725, 6);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 1;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tableLayoutPanel1.Size = new Size(200, 51);
            tableLayoutPanel1.TabIndex = 5;
            // 
            // btnCerrarCaja
            // 
            btnCerrarCaja.BackColor = Color.FromArgb(8, 126, 164);
            btnCerrarCaja.Cursor = Cursors.Hand;
            btnCerrarCaja.Dock = DockStyle.Fill;
            btnCerrarCaja.FlatAppearance.BorderSize = 0;
            btnCerrarCaja.FlatStyle = FlatStyle.Flat;
            btnCerrarCaja.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnCerrarCaja.ForeColor = Color.White;
            btnCerrarCaja.Location = new Point(3, 3);
            btnCerrarCaja.Name = "btnCerrarCaja";
            btnCerrarCaja.Size = new Size(194, 45);
            btnCerrarCaja.TabIndex = 3;
            btnCerrarCaja.Text = "CERRAR CAJA";
            btnCerrarCaja.UseVisualStyleBackColor = false;
            btnCerrarCaja.Click += btnCerrarCaja_Click;
            // 
            // tlpButtons
            // 
            tlpButtons.ColumnCount = 3;
            tlpButtons.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.3333321F));
            tlpButtons.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.3333321F));
            tlpButtons.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.3333321F));
            tlpButtons.Controls.Add(btnAbrirCaja, 0, 0);
            tlpButtons.Controls.Add(btnRegistrarEgreso, 2, 0);
            tlpButtons.Controls.Add(btnRegistrarIngreso, 1, 0);
            tlpButtons.Dock = DockStyle.Left;
            tlpButtons.Location = new Point(15, 6);
            tlpButtons.Margin = new Padding(10, 3, 3, 3);
            tlpButtons.Name = "tlpButtons";
            tlpButtons.RowCount = 1;
            tlpButtons.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tlpButtons.RowStyles.Add(new RowStyle(SizeType.Absolute, 20F));
            tlpButtons.Size = new Size(450, 51);
            tlpButtons.TabIndex = 4;
            // 
            // btnAbrirCaja
            // 
            btnAbrirCaja.BackColor = Color.LightSkyBlue;
            btnAbrirCaja.Cursor = Cursors.Hand;
            btnAbrirCaja.Dock = DockStyle.Fill;
            btnAbrirCaja.FlatAppearance.BorderSize = 0;
            btnAbrirCaja.FlatStyle = FlatStyle.Flat;
            btnAbrirCaja.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAbrirCaja.ForeColor = Color.FromArgb(8, 31, 63);
            btnAbrirCaja.Location = new Point(3, 3);
            btnAbrirCaja.Name = "btnAbrirCaja";
            btnAbrirCaja.Size = new Size(143, 45);
            btnAbrirCaja.TabIndex = 0;
            btnAbrirCaja.Text = "ABRIR CAJA";
            btnAbrirCaja.UseVisualStyleBackColor = false;
            btnAbrirCaja.Click += btnAbrirCaja_Click;
            // 
            // btnRegistrarEgreso
            // 
            btnRegistrarEgreso.BackColor = Color.FromArgb(238, 243, 247);
            btnRegistrarEgreso.Cursor = Cursors.Hand;
            btnRegistrarEgreso.Dock = DockStyle.Fill;
            btnRegistrarEgreso.FlatAppearance.BorderSize = 0;
            btnRegistrarEgreso.FlatStyle = FlatStyle.Flat;
            btnRegistrarEgreso.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnRegistrarEgreso.ForeColor = Color.FromArgb(8, 31, 63);
            btnRegistrarEgreso.Location = new Point(301, 3);
            btnRegistrarEgreso.Name = "btnRegistrarEgreso";
            btnRegistrarEgreso.Size = new Size(146, 45);
            btnRegistrarEgreso.TabIndex = 2;
            btnRegistrarEgreso.Text = "EGRESO";
            btnRegistrarEgreso.UseVisualStyleBackColor = false;
            btnRegistrarEgreso.Click += btnRegistrarEgreso_Click;
            // 
            // btnRegistrarIngreso
            // 
            btnRegistrarIngreso.BackColor = Color.FromArgb(238, 243, 247);
            btnRegistrarIngreso.Cursor = Cursors.Hand;
            btnRegistrarIngreso.Dock = DockStyle.Fill;
            btnRegistrarIngreso.FlatAppearance.BorderSize = 0;
            btnRegistrarIngreso.FlatStyle = FlatStyle.Flat;
            btnRegistrarIngreso.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnRegistrarIngreso.ForeColor = Color.FromArgb(8, 31, 63);
            btnRegistrarIngreso.Location = new Point(152, 3);
            btnRegistrarIngreso.Name = "btnRegistrarIngreso";
            btnRegistrarIngreso.Size = new Size(143, 45);
            btnRegistrarIngreso.TabIndex = 1;
            btnRegistrarIngreso.Text = "INGRESO";
            btnRegistrarIngreso.UseVisualStyleBackColor = false;
            btnRegistrarIngreso.Click += btnRegistrarIngreso_Click;
            // 
            // pnlUltimoCierre
            // 
            pnlUltimoCierre.BackColor = Color.White;
            pnlUltimoCierre.Controls.Add(tlpUltimoCierre);
            pnlUltimoCierre.Controls.Add(lblTituloUltimoCierre);
            pnlUltimoCierre.Dock = DockStyle.Top;
            pnlUltimoCierre.Location = new Point(0, 175);
            pnlUltimoCierre.Name = "pnlUltimoCierre";
            pnlUltimoCierre.Padding = new Padding(8);
            pnlUltimoCierre.Size = new Size(940, 85);
            pnlUltimoCierre.TabIndex = 1;
            // 
            // tlpUltimoCierre
            // 
            tlpUltimoCierre.ColumnCount = 5;
            tlpUltimoCierre.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25.581398F));
            tlpUltimoCierre.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 18.6046524F));
            tlpUltimoCierre.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 18.6046524F));
            tlpUltimoCierre.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 18.6046524F));
            tlpUltimoCierre.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 18.6046524F));
            tlpUltimoCierre.Controls.Add(pnlUltimoCierreFecha, 0, 0);
            tlpUltimoCierre.Controls.Add(pnlUltimoCierreEsperado, 1, 0);
            tlpUltimoCierre.Controls.Add(pnlUltimoCierreContado, 2, 0);
            tlpUltimoCierre.Controls.Add(pnlUltimoCierreDiferencia, 3, 0);
            tlpUltimoCierre.Controls.Add(pnlUltimoCierreUsuario, 4, 0);
            tlpUltimoCierre.Dock = DockStyle.Fill;
            tlpUltimoCierre.Location = new Point(8, 26);
            tlpUltimoCierre.Name = "tlpUltimoCierre";
            tlpUltimoCierre.RowCount = 1;
            tlpUltimoCierre.RowStyles.Add(new RowStyle(SizeType.Percent, 100F));
            tlpUltimoCierre.Size = new Size(924, 51);
            tlpUltimoCierre.TabIndex = 1;
            // 
            // pnlUltimoCierreFecha
            // 
            pnlUltimoCierreFecha.BackColor = Color.FromArgb(245, 247, 250);
            pnlUltimoCierreFecha.Controls.Add(lblUltimoCierreFecha);
            pnlUltimoCierreFecha.Dock = DockStyle.Fill;
            pnlUltimoCierreFecha.Location = new Point(3, 3);
            pnlUltimoCierreFecha.Name = "pnlUltimoCierreFecha";
            pnlUltimoCierreFecha.Padding = new Padding(2);
            pnlUltimoCierreFecha.Size = new Size(230, 45);
            pnlUltimoCierreFecha.TabIndex = 0;
            // 
            // lblUltimoCierreFecha
            // 
            lblUltimoCierreFecha.Dock = DockStyle.Fill;
            lblUltimoCierreFecha.Font = new Font("Century Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lblUltimoCierreFecha.ForeColor = Color.FromArgb(8, 31, 63);
            lblUltimoCierreFecha.Location = new Point(2, 2);
            lblUltimoCierreFecha.Name = "lblUltimoCierreFecha";
            lblUltimoCierreFecha.Size = new Size(226, 41);
            lblUltimoCierreFecha.TabIndex = 1;
            lblUltimoCierreFecha.Text = "Fecha: -";
            lblUltimoCierreFecha.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pnlUltimoCierreEsperado
            // 
            pnlUltimoCierreEsperado.BackColor = Color.FromArgb(238, 246, 248);
            pnlUltimoCierreEsperado.Controls.Add(lblUltimoCierreEsperado);
            pnlUltimoCierreEsperado.Dock = DockStyle.Fill;
            pnlUltimoCierreEsperado.Location = new Point(239, 3);
            pnlUltimoCierreEsperado.Name = "pnlUltimoCierreEsperado";
            pnlUltimoCierreEsperado.Padding = new Padding(2);
            pnlUltimoCierreEsperado.Size = new Size(165, 45);
            pnlUltimoCierreEsperado.TabIndex = 1;
            // 
            // lblUltimoCierreEsperado
            // 
            lblUltimoCierreEsperado.Dock = DockStyle.Fill;
            lblUltimoCierreEsperado.Font = new Font("Century Gothic", 9F);
            lblUltimoCierreEsperado.ForeColor = Color.FromArgb(8, 126, 164);
            lblUltimoCierreEsperado.Location = new Point(2, 2);
            lblUltimoCierreEsperado.Name = "lblUltimoCierreEsperado";
            lblUltimoCierreEsperado.Size = new Size(161, 41);
            lblUltimoCierreEsperado.TabIndex = 2;
            lblUltimoCierreEsperado.Text = "Esperado: C$ 0.00";
            lblUltimoCierreEsperado.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pnlUltimoCierreContado
            // 
            pnlUltimoCierreContado.BackColor = Color.FromArgb(238, 247, 241);
            pnlUltimoCierreContado.Controls.Add(lblUltimoCierreContado);
            pnlUltimoCierreContado.Dock = DockStyle.Fill;
            pnlUltimoCierreContado.Location = new Point(410, 3);
            pnlUltimoCierreContado.Name = "pnlUltimoCierreContado";
            pnlUltimoCierreContado.Padding = new Padding(2);
            pnlUltimoCierreContado.Size = new Size(165, 45);
            pnlUltimoCierreContado.TabIndex = 2;
            // 
            // lblUltimoCierreContado
            // 
            lblUltimoCierreContado.Dock = DockStyle.Fill;
            lblUltimoCierreContado.Font = new Font("Century Gothic", 9F);
            lblUltimoCierreContado.ForeColor = Color.FromArgb(42, 122, 82);
            lblUltimoCierreContado.Location = new Point(2, 2);
            lblUltimoCierreContado.Name = "lblUltimoCierreContado";
            lblUltimoCierreContado.Size = new Size(161, 41);
            lblUltimoCierreContado.TabIndex = 3;
            lblUltimoCierreContado.Text = "Contado: C$ 0.00";
            lblUltimoCierreContado.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pnlUltimoCierreDiferencia
            // 
            pnlUltimoCierreDiferencia.BackColor = Color.FromArgb(255, 247, 232);
            pnlUltimoCierreDiferencia.Controls.Add(lblUltimoCierreDiferencia);
            pnlUltimoCierreDiferencia.Dock = DockStyle.Fill;
            pnlUltimoCierreDiferencia.Location = new Point(581, 3);
            pnlUltimoCierreDiferencia.Name = "pnlUltimoCierreDiferencia";
            pnlUltimoCierreDiferencia.Padding = new Padding(2);
            pnlUltimoCierreDiferencia.Size = new Size(165, 45);
            pnlUltimoCierreDiferencia.TabIndex = 3;
            // 
            // lblUltimoCierreDiferencia
            // 
            lblUltimoCierreDiferencia.BackColor = Color.FromArgb(255, 247, 232);
            lblUltimoCierreDiferencia.Dock = DockStyle.Fill;
            lblUltimoCierreDiferencia.Font = new Font("Century Gothic", 9F);
            lblUltimoCierreDiferencia.ForeColor = Color.FromArgb(181, 119, 23);
            lblUltimoCierreDiferencia.Location = new Point(2, 2);
            lblUltimoCierreDiferencia.Name = "lblUltimoCierreDiferencia";
            lblUltimoCierreDiferencia.Size = new Size(161, 41);
            lblUltimoCierreDiferencia.TabIndex = 4;
            lblUltimoCierreDiferencia.Text = "Diferencia: C$ 0.00";
            lblUltimoCierreDiferencia.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pnlUltimoCierreUsuario
            // 
            pnlUltimoCierreUsuario.BackColor = Color.FromArgb(245, 247, 250);
            pnlUltimoCierreUsuario.Controls.Add(lblUltimoCierreUsuario);
            pnlUltimoCierreUsuario.Dock = DockStyle.Fill;
            pnlUltimoCierreUsuario.Location = new Point(752, 3);
            pnlUltimoCierreUsuario.Name = "pnlUltimoCierreUsuario";
            pnlUltimoCierreUsuario.Padding = new Padding(2);
            pnlUltimoCierreUsuario.Size = new Size(169, 45);
            pnlUltimoCierreUsuario.TabIndex = 4;
            // 
            // lblUltimoCierreUsuario
            // 
            lblUltimoCierreUsuario.Dock = DockStyle.Fill;
            lblUltimoCierreUsuario.Font = new Font("Century Gothic", 9F);
            lblUltimoCierreUsuario.ForeColor = Color.FromArgb(8, 31, 63);
            lblUltimoCierreUsuario.Location = new Point(2, 2);
            lblUltimoCierreUsuario.Name = "lblUltimoCierreUsuario";
            lblUltimoCierreUsuario.Size = new Size(165, 41);
            lblUltimoCierreUsuario.TabIndex = 5;
            lblUltimoCierreUsuario.Text = "Usuario: -";
            lblUltimoCierreUsuario.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // lblTituloUltimoCierre
            // 
            lblTituloUltimoCierre.Dock = DockStyle.Top;
            lblTituloUltimoCierre.Font = new Font("Century Gothic", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lblTituloUltimoCierre.ForeColor = Color.FromArgb(8, 31, 63);
            lblTituloUltimoCierre.Location = new Point(8, 8);
            lblTituloUltimoCierre.Name = "lblTituloUltimoCierre";
            lblTituloUltimoCierre.Size = new Size(924, 18);
            lblTituloUltimoCierre.TabIndex = 0;
            lblTituloUltimoCierre.Text = "Ú L T I M O   C I E R R E";
            lblTituloUltimoCierre.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // FrmCaja
            // 
            AutoScaleDimensions = new SizeF(120F, 120F);
            AutoScaleMode = AutoScaleMode.Dpi;
            BackColor = Color.FromArgb(245, 247, 250);
            ClientSize = new Size(940, 830);
            Controls.Add(pnlAcciones);
            Controls.Add(pnlMovimientos);
            Controls.Add(pnlUltimoCierre);
            Controls.Add(pnlResumen);
            Controls.Add(pnlEstadoCaja);
            FormBorderStyle = FormBorderStyle.None;
            Name = "FrmCaja";
            Text = "FrmCaja";
            FormClosed += FrmCaja_FormClosed;
            pnlEstadoCaja.ResumeLayout(false);
            pnlResumen.ResumeLayout(false);
            tlpResumen.ResumeLayout(false);
            pnlResumenApertura.ResumeLayout(false);
            pnlResumenIngresos.ResumeLayout(false);
            pnlResumenEgresos.ResumeLayout(false);
            pnlResumenEsperado.ResumeLayout(false);
            pnlMovimientos.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)dgvMovimientosCaja).EndInit();
            pnlAcciones.ResumeLayout(false);
            tableLayoutPanel1.ResumeLayout(false);
            tlpButtons.ResumeLayout(false);
            pnlUltimoCierre.ResumeLayout(false);
            tlpUltimoCierre.ResumeLayout(false);
            pnlUltimoCierreFecha.ResumeLayout(false);
            pnlUltimoCierreEsperado.ResumeLayout(false);
            pnlUltimoCierreContado.ResumeLayout(false);
            pnlUltimoCierreDiferencia.ResumeLayout(false);
            pnlUltimoCierreUsuario.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private Panel pnlEstadoCaja;
        private Label lblDetalleCaja;
        private Label lblEstadoCaja;
        private Label lblEstadoTitulo;
        private Panel pnlResumen;
        private TableLayoutPanel tlpResumen;
        private Panel pnlResumenApertura;
        private Panel pnlResumenIngresos;
        private Label lblValorApertura;
        private Label lblTituloApertura;
        private Panel pnlResumenEgresos;
        private Panel pnlResumenEsperado;
        private Label lblValorIngresos;
        private Label lblTituloIngresos;
        private Label lblValorEgresos;
        private Label lblTituloEgresos;
        private Label lblValorEsperado;
        private Label lblTituloEsperado;
        private Panel pnlMovimientos;
        private DataGridView dgvMovimientosCaja;
        private Panel pnlAcciones;
        private Button btnRegistrarEgreso;
        private Button btnRegistrarIngreso;
        private Button btnAbrirCaja;
        private Button btnCerrarCaja;
        private TableLayoutPanel tlpButtons;
        private TableLayoutPanel tableLayoutPanel1;
        private Panel pnlUltimoCierre;
        private Label lblTituloUltimoCierre;
        private TableLayoutPanel tlpUltimoCierre;
        private Panel pnlUltimoCierreFecha;
        private Label lblUltimoCierreEsperado;
        private Label lblUltimoCierreContado;
        private Label lblUltimoCierreDiferencia;
        private Label lblUltimoCierreUsuario;
        private Panel pnlUltimoCierreEsperado;
        private Panel pnlUltimoCierreContado;
        private Panel pnlUltimoCierreDiferencia;
        private Panel pnlUltimoCierreUsuario;
        private Label lblUltimoCierreFecha;
        private DataGridViewTextBoxColumn colFecha;
        private DataGridViewTextBoxColumn colTipo;
        private DataGridViewTextBoxColumn colConcepto;
        private DataGridViewTextBoxColumn colMetodo;
        private DataGridViewTextBoxColumn colMonto;
        private DataGridViewTextBoxColumn colUsuario;
    }
}